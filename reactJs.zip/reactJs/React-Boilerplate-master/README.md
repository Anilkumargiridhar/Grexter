![](http://i.imgur.com/5Bqs5zi.png)

React boilerplate thenewboston tutorials.

## Getting started

To get started simply download the repo using the link below. All required files are included.

https://github.com/buckyroberts/React-Boilerplate/archive/master.zip

## Setting up Gulp (optional)

You can also use Gulp to add additional build tasks. To use, follow the instructions below.

Navigate to the root directory and  run the following command:
```
> npm install
```

After modules are installed, you can start watching for SCSS changes using the command:
```
> gulp
```

You can install more modules and configure them in the **gulpfile.js** file as needed.

## Links

- [Support thenewboston](https://www.patreon.com/thenewboston)
- [thenewboston.com](https://thenewboston.com/)
- [Facebook](https://www.facebook.com/TheNewBoston-464114846956315/)
- [Twitter](https://twitter.com/bucky_roberts)
- [Google+](https://plus.google.com/+BuckyRoberts)
- [reddit](https://www.reddit.com/r/thenewboston/)
